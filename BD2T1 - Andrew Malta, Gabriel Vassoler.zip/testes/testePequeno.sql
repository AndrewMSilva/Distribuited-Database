create table cliente (nome varchar(257), id int, sobrenome char(30))
insert into cliente('Antonio hgghfdg', 5, 'que')
insert into cliente('Joao dhusjaid', 8, 'que')
select * from cliente